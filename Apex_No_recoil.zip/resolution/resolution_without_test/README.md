# Customized resolutions
In this folder, I will collect some resolutions from others. 

# How to use
Just replace the content in the `customized.ini` to the one you want and choose **customized** in the gui resolution setting. Then it will work.


# Tested by community
- [] 3840x1440
- [] 3840x1600